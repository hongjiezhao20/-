library(bio3d)
pdb <- read.pdb("protein_dry.pdb")
dcd <- read.dcd("prod_all1.dcd")
#A
a.inds <- atom.select(pdb,resno=1:578,elety="CA")
axyz <- fit.xyz(fixed=pdb$xyz, mobile=dcd,
               fixed.inds=a.inds$xyz,
               mobile.inds=a.inds$xyz)
dim(axyz) == dim(dcd)
rf <- rmsf(axyz[,a.inds$xyz])
png(filename = "ARMSF.png",width = 582, height = 482, units = "px")
plot(rf, ylab="ARMSF", xlab="Residue Position", typ="l",xlim=c(1,578),ylim=c(0.4,7))
dev.off()
df=data.frame(values=rf)
write.csv(df,file="rmsfA.csv",row.names=FALSE)
rm(axyz,rf,a.inds,df)
gc()	
#B
b.inds <- atom.select(pdb,resno=579:1156,elety="CA")
bxyz <- fit.xyz(fixed=pdb$xyz, mobile=dcd,
               fixed.inds=b.inds$xyz,
               mobile.inds=b.inds$xyz)
dim(bxyz) == dim(dcd)
rf <- rmsf(bxyz[,b.inds$xyz])
png(filename = "BRMSF.png",width = 582, height = 482, units = "px")
plot(rf, ylab="BRMSF", xlab="Residue Position", typ="l",xlim=c(1,578),ylim=c(0.4,7))
dev.off()
df=data.frame(values=rf)
write.csv(df,file="rmsfB.csv",row.names=FALSE)
rm(bxyz,rf,b.inds,df)
gc()
#C
c.inds <- atom.select(pdb,resno=1157:1734,elety="CA")
cxyz <- fit.xyz(fixed=pdb$xyz, mobile=dcd,
               fixed.inds=c.inds$xyz,
               mobile.inds=c.inds$xyz)
dim(cxyz) == dim(dcd)
rf <- rmsf(cxyz[,c.inds$xyz])
png(filename = "CRMSF.png",width = 582, height = 482, units = "px")
plot(rf, ylab="CRMSF", xlab="Residue Position", typ="l",xlim=c(1,578),ylim=c(0.4,7))
dev.off()
df=data.frame(values=rf)
write.csv(df,file="rmsfC.csv",row.names=FALSE)
rm(cxyz,rf,c.inds,df)
gc()
#D
d.inds <- atom.select(pdb,resno=1735:2312,elety="CA")
dxyz <- fit.xyz(fixed=pdb$xyz, mobile=dcd,
               fixed.inds=d.inds$xyz,
               mobile.inds=d.inds$xyz)
dim(dxyz) == dim(dcd)
rf <- rmsf(dxyz[,d.inds$xyz])
png(filename = "DRMSF.png",width = 582, height = 482, units = "px")
plot(rf, ylab="DRMSF", xlab="Residue Position", typ="l",xlim=c(1,578),ylim=c(0.4,7))
dev.off()
df=data.frame(values=rf)
write.csv(df,file="rmsfD.csv",row.names=FALSE)
rm(dxyz,rf,d.inds,df)
gc()
q()
