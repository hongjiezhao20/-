library(bio3d)
pdb <- read.pdb("protein_dry.pdb")
dcd <- read.dcd("prod_all1.dcd")
ca.inds <- atom.select(pdb, elety="CA")
xyz <- fit.xyz(fixed=pdb$xyz, mobile=dcd,
               fixed.inds=ca.inds$xyz,
               mobile.inds=ca.inds$xyz)
save(xyz,file="xyz.RData")#save xyz as a RData document
rd <- rmsd(xyz[1,ca.inds$xyz], xyz[,ca.inds$xyz])
rm(xyz) #clean xyz
#RMSD-Frame No.
png(filename = "RMSD.png",width = 582, height = 482, units = "px")
plot(rd, typ="l", ylab="RMSD", xlab="Frame No.")
points(lowess(rd), typ="l", col="red", lty=2, lwd=2)
dev.off()
#Density-RMSD
png(filename = "RMSD_density.png",width = 582, height = 482, units = "px")
hist(rd, breaks=40, freq=FALSE, main="RMSD Histogram", xlab="RMSD")
lines(density(rd), col="gray", lwd=3)
dev.off()
q()



