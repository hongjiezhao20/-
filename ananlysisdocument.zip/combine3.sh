#!/bin/bash -l
export CUDA_VISIBLE_DEVICES=6 &&
#combine3
cpptraj.cuda -i combine_md_nc_3.in

