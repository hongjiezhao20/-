#!/bin/bash -l
export CUDA_VISIBLE_DEVICES=6 &&
#combine1
cpptraj.cuda -i combine_md_nc_1.in


