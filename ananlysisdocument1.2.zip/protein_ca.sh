#!/bin/bash -l
export CUDA_VISIBLE_DEVICES=6 &&
cpptraj.cuda -i protein_ca.in

