#!/bin/bash -l
export CUDA_VISIBLE_DEVICES=6 &&
#combine2
cpptraj.cuda -i combine_md_nc_2.in


