#!/usr/bin/Rscript
library(bio3d)
pdb <- read.pdb("protein_dry.pdb")
dcd <- read.dcd("prod_all1.dcd")
ca.inds <- atom.select(pdb, elety="CA")
xyz <- fit.xyz(fixed=pdb$xyz, mobile=dcd,
               fixed.inds=ca.inds$xyz,
               mobile.inds=ca.inds$xyz)
dim(xyz) == dim(dcd)
cij<-dccm(xyz[,ca.inds$xyz])
write.csv(cij,file='dccm_0318')
q()

